import axios from "axios";
import { useEffect, useState } from "react";

interface WeatherData {
	temperature: number | null;
	description: string;
}

export default function Weather({ lat, lon }: { lat: number; lon: number }) {
	const [data, setData] = useState<WeatherData>({ temperature: null, description: "" });
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		async function fetchWeather() {
			setLoading(true);
			const base = import.meta.env.VITE_OPEN_METEO_BASE || "https://api.open-meteo.com/v1/forecast";
			const url = `${base}?latitude=${lat}&longitude=${lon}&current_weather=true`;
			const res = await axios.get(url);
			const temp = res.data?.current_weather?.temperature ?? null;
			const wind = res.data?.current_weather?.windspeed ?? 0;
			setData({ temperature: temp, description: `Wind ${wind} km/h` });
			setLoading(false);
		}
		fetchWeather();
	}, [lat, lon]);

	if (loading) return <div className="loading loading-spinner" />;

	return (
		<div className="alert">
			<div>
				<h3 className="font-bold">Weather</h3>
				<div className="text-sm">Temp: {data.temperature}°C • {data.description}</div>
			</div>
		</div>
	);
}