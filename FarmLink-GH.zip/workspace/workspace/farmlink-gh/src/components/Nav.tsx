import { Link, NavLink } from "react-router-dom";
import { auth } from "../firebase";
import { useEffect, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";

export default function Nav() {
	const [userEmail, setUserEmail] = useState<string | null>(null);
	useEffect(() => {
		return onAuthStateChanged(auth, (u) => setUserEmail(u?.email ?? null));
	}, []);
	return (
		<div className="navbar bg-base-100 shadow">
			<div className="container mx-auto">
				<div className="flex-1">
					<Link to="/" className="btn btn-ghost text-xl">FarmLink GH</Link>
				</div>
				<div className="flex-none">
					<ul className="menu menu-horizontal px-1">
						<li><NavLink to="/" className={({ isActive }) => isActive ? "active" : ""}>Home</NavLink></li>
						{userEmail && (<>
							<li><NavLink to="/app/listings" className={({ isActive }) => isActive ? "active" : ""}>Listings</NavLink></li>
							<li><button onClick={() => signOut(auth)}>Logout</button></li>
						</>)}
						{!userEmail && (<>
							<li><NavLink to="/login">Login</NavLink></li>
							<li><NavLink to="/register">Register</NavLink></li>
						</>)}
					</ul>
				</div>
			</div>
		</div>
	);
}