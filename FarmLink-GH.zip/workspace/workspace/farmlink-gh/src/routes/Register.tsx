import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";
import { Link, useNavigate } from "react-router-dom";

const schema = z.object({
	email: z.string().email(),
	password: z.string().min(6),
});

type FormData = z.infer<typeof schema>;

export default function Register() {
	const navigate = useNavigate();
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
		resolver: zodResolver(schema),
	});

	async function onSubmit(data: FormData) {
		await createUserWithEmailAndPassword(auth, data.email, data.password);
		navigate("/app/listings");
	}

	return (
		<div className="min-h-screen flex items-center justify-center p-6">
			<div className="card w-full max-w-md bg-base-100 shadow">
				<div className="card-body">
					<h2 className="card-title">Create Account</h2>
					<form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
						<div>
							<label className="label">Email</label>
							<input {...register("email")} className="input input-bordered w-full" />
							{errors.email && <p className="text-error text-sm">{errors.email.message}</p>}
						</div>
						<div>
							<label className="label">Password</label>
							<input type="password" {...register("password")} className="input input-bordered w-full" />
							{errors.password && <p className="text-error text-sm">{errors.password.message}</p>}
						</div>
						<button disabled={isSubmitting} className="btn btn-primary w-full">{isSubmitting ? "Creating..." : "Register"}</button>
					</form>
					<p className="text-sm">Have an account? <Link className="link" to="/login">Login</Link></p>
				</div>
			</div>
		</div>
	);
}