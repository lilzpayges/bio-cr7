import { useEffect, useState } from "react";
import { collection, onSnapshot, query, orderBy, deleteDoc, doc } from "firebase/firestore";
import { db, auth } from "../firebase";
import { Link } from "react-router-dom";
import { signOut } from "firebase/auth";

export type Listing = {
	id: string;
	title: string;
	price: number;
	quantity: number;
	location: string;
	createdAt?: any;
	ownerUid: string;
};

export default function Listings() {
	const [listings, setListings] = useState<Listing[]>([]);

	useEffect(() => {
		const q = query(collection(db, "listings"), orderBy("createdAt", "desc"));
		const unsub = onSnapshot(q, (snap) => {
			const data: Listing[] = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Listing, "id">) }));
			setListings(data);
		});
		return () => unsub();
	}, []);

	async function handleDelete(id: string, ownerUid: string) {
		if (auth.currentUser?.uid !== ownerUid) return;
		await deleteDoc(doc(db, "listings", id));
	}

	return (
		<div className="min-h-screen p-4 max-w-4xl mx-auto">
			<div className="flex items-center justify-between mb-4">
				<h1 className="text-2xl font-bold">Your Market</h1>
				<div className="flex gap-2">
					<Link to="/app/listings/new" className="btn btn-primary">New Listing</Link>
					<button className="btn" onClick={() => signOut(auth)}>Logout</button>
				</div>
			</div>
			<div className="grid md:grid-cols-2 gap-4">
				{listings.map((item) => (
					<div key={item.id} className="card bg-base-100 shadow">
						<div className="card-body">
							<h2 className="card-title">{item.title}</h2>
							<p className="text-sm">Location: {item.location}</p>
							<p className="text-sm">Qty: {item.quantity} • Price: GHS {item.price}</p>
							{auth.currentUser?.uid === item.ownerUid && (
							<div className="card-actions justify-end gap-2">
								<Link to={`/app/listings/${item.id}/edit`} className="btn btn-outline">Edit</Link>
								<button className="btn btn-error btn-outline" onClick={() => handleDelete(item.id, item.ownerUid)}>Delete</button>
							</div>
						)}
						</div>
					</div>
				))}
			</div>
		</div>
	);
}