import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { db, auth } from "../firebase";
import { useNavigate, useParams } from "react-router-dom";

const schema = z.object({
	title: z.string().min(2),
	price: z.number().min(0),
	quantity: z.number().min(1),
	location: z.string().min(2),
});

type FormData = z.infer<typeof schema>;

export default function EditListing() {
	const navigate = useNavigate();
	const { id } = useParams();
	const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<FormData>({
		resolver: zodResolver(schema),
	});

	useEffect(() => {
		async function load() {
			if (!id) return;
			const ref = doc(db, "listings", id);
			const snap = await getDoc(ref);
			const data = snap.data();
			if (!data) return;
			if (auth.currentUser?.uid !== data.ownerUid) {
				navigate("/app/listings", { replace: true });
				return;
			}
			reset({
				title: data.title,
				price: data.price,
				quantity: data.quantity,
				location: data.location,
			});
		}
		load();
	}, [id, navigate, reset]);

	async function onSubmit(data: FormData) {
		if (!id) return;
		const ref = doc(db, "listings", id);
		await updateDoc(ref, {
			title: data.title,
			price: Number(data.price),
			quantity: Number(data.quantity),
			location: data.location,
		});
		navigate("/app/listings");
	}

	return (
		<div className="min-h-screen p-4 max-w-xl mx-auto">
			<h1 className="text-2xl font-bold mb-4">Edit Listing</h1>
			<form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
				<div>
					<label className="label">Title</label>
					<input className="input input-bordered w-full" {...register("title")} />
					{errors.title && <p className="text-error text-sm">{errors.title.message}</p>}
				</div>
				<div className="grid grid-cols-2 gap-3">
					<div>
						<label className="label">Price (GHS)</label>
						<input type="number" className="input input-bordered w-full" {...register("price", { valueAsNumber: true })} />
						{errors.price && <p className="text-error text-sm">{errors.price.message}</p>}
					</div>
					<div>
						<label className="label">Quantity</label>
						<input type="number" className="input input-bordered w-full" {...register("quantity", { valueAsNumber: true })} />
						{errors.quantity && <p className="text-error text-sm">{errors.quantity.message}</p>}
					</div>
				</div>
				<div>
					<label className="label">Location</label>
					<input className="input input-bordered w-full" {...register("location")} />
					{errors.location && <p className="text-error text-sm">{errors.location.message}</p>}
				</div>
				<button disabled={isSubmitting} className="btn btn-primary">{isSubmitting ? "Saving..." : "Save Changes"}</button>
			</form>
		</div>
	);
}