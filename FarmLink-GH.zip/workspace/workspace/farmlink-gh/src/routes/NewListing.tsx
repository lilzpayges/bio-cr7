import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db, auth } from "../firebase";
import { useNavigate } from "react-router-dom";

const schema = z.object({
	title: z.string().min(2),
	price: z.number().min(0),
	quantity: z.number().min(1),
	location: z.string().min(2),
});

type FormData = z.infer<typeof schema>;

export default function NewListing() {
	const navigate = useNavigate();
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
		resolver: zodResolver(schema),
	});

	async function onSubmit(data: FormData) {
		const user = auth.currentUser;
		if (!user) return;
		await addDoc(collection(db, "listings"), {
			...data,
			price: Number(data.price),
			quantity: Number(data.quantity),
			createdAt: serverTimestamp(),
			ownerUid: user.uid,
		});
		navigate("/app/listings");
	}

	return (
		<div className="min-h-screen p-4 max-w-xl mx-auto">
			<h1 className="text-2xl font-bold mb-4">New Listing</h1>
			<form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
				<div>
					<label className="label">Title</label>
					<input className="input input-bordered w-full" {...register("title")} />
					{errors.title && <p className="text-error text-sm">{errors.title.message}</p>}
				</div>
				<div className="grid grid-cols-2 gap-3">
					<div>
						<label className="label">Price (GHS)</label>
						<input type="number" step="0.01" className="input input-bordered w-full" {...register("price", { valueAsNumber: true })} />
						{errors.price && <p className="text-error text-sm">{errors.price.message}</p>}
					</div>
					<div>
						<label className="label">Quantity</label>
						<input type="number" className="input input-bordered w-full" {...register("quantity", { valueAsNumber: true })} />
						{errors.quantity && <p className="text-error text-sm">{errors.quantity.message}</p>}
					</div>
				</div>
				<div>
					<label className="label">Location</label>
					<input className="input input-bordered w-full" {...register("location")} />
					{errors.location && <p className="text-error text-sm">{errors.location.message}</p>}
				</div>
				<button disabled={isSubmitting} className="btn btn-primary">{isSubmitting ? "Saving..." : "Save"}</button>
			</form>
		</div>
	);
}