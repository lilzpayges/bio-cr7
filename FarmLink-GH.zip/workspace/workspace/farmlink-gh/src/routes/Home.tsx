import { Link } from "react-router-dom";

export default function Home() {
	return (
		<div className="min-h-screen flex flex-col items-center justify-center p-6">
			<h1 className="text-4xl font-bold mb-4">FarmLink GH</h1>
			<p className="mb-8 text-center max-w-xl">
				Connect Ghanaian farmers with buyers, market prices, and weather insights.
			</p>
			<div className="flex gap-3">
				<Link to="/login" className="btn btn-primary">Login</Link>
				<Link to="/register" className="btn btn-outline">Create account</Link>
			</div>
		</div>
	);
}