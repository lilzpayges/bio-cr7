import AppRouter from './router'
import Weather from './components/Weather'

export default function App() {
	return (
		<div className="min-h-screen">
			<div className="container mx-auto p-4">
				<Weather lat={5.6037} lon={-0.1870} />
			</div>
			<AppRouter />
		</div>
	)
}
