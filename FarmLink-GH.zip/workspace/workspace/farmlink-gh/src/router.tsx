import { createBrowserRouter, RouterProvider, Outlet, Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { useEffect, useState } from "react";
import { auth } from "./firebase";
import Home from "./routes/Home";
import Login from "./routes/Login";
import Register from "./routes/Register";
import Listings from "./routes/Listings";
import NewListing from "./routes/NewListing";
import EditListing from "./routes/EditListing";

function ProtectedRoute() {
	const [isLoading, setIsLoading] = useState(true);
	const [isAuthenticated, setIsAuthenticated] = useState(false);

	useEffect(() => {
		const unsub = onAuthStateChanged(auth, (user) => {
			setIsAuthenticated(!!user);
			setIsLoading(false);
		});
		return () => unsub();
	}, []);

	if (isLoading) {
		return <div className="flex h-screen items-center justify-center">Loading...</div>;
	}

	return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
}

const router = createBrowserRouter([
	{
		path: "/",
		element: <Home />,
	},
	{
		path: "/login",
		element: <Login />,
	},
	{
		path: "/register",
		element: <Register />,
	},
	{
		path: "/app",
		element: <ProtectedRoute />,
		children: [
			{ path: "listings", element: <Listings /> },
			{ path: "listings/new", element: <NewListing /> },
			{ path: "listings/:id/edit", element: <EditListing /> },
		],
	},
]);

export default function AppRouter() {
	return <RouterProvider router={router} />;
}