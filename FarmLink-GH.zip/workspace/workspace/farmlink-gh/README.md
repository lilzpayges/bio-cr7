# FarmLink GH

A web application connecting Ghanaian farmers with buyers, providing simple listings, authentication, and a weather widget powered by Open-Meteo. Built with React + Vite + TypeScript, Firebase (Auth + Firestore), TailwindCSS + DaisyUI.

## Features
- Email/password authentication (Firebase Auth)
- CRUD for product listings (Firestore)
- Weather widget (Open-Meteo API)
- Protected routes
- Responsive UI (Tailwind + DaisyUI)

## Getting Started
1. Copy `.env.example` to `.env` and fill in Firebase config
2. Install dependencies
```bash
npm install
```
3. Run the dev server
```bash
npm run dev
```

## Tech Stack
- React + Vite + TypeScript
- Firebase: Auth, Firestore
- TailwindCSS + DaisyUI
- Open-Meteo API

## Scripts
- `npm run dev` - Start dev server
- `npm run build` - Production build
- `npm run preview` - Preview built app
